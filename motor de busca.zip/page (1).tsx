import { Suspense, type ReactNode } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Logo } from '@/components/logo';
import SearchBar from '@/components/search-bar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { searchTheWeb } from '@/ai/flows/search-the-web';
import { summarizeSearchResults } from '@/ai/flows/summarize-results';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { searchImages } from '@/ai/flows/search-images';
import { searchVideos } from '@/ai/flows/search-videos';
import { searchNews } from '@/ai/flows/search-news';
import { Skeleton } from '@/components/ui/skeleton';
import { Newspaper } from 'lucide-react';

function WebSearchResultsSkeleton() {
  return (
    <div className="space-y-6">
      <Card className="bg-muted/20">
        <CardHeader>
          <Skeleton className="h-6 w-1/4" />
        </CardHeader>
        <CardContent className="space-y-3">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
        </CardContent>
      </Card>
      <div className="space-y-6">
        {Array.from({ length: 5 }).map((_, i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-5 w-3/4 mb-2" />
              <Skeleton className="h-3 w-1/2" />
            </CardHeader>
            <CardContent className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

async function WebSearchResults({ query }: { query: string }) {
  if (!query) {
    return null;
  }

  const searchData = await searchTheWeb({ query });
  const { results } = searchData;

  let summary = '';
  if (results.length > 0) {
    try {
      const resultsForSummary = results.map(({ title, link, snippet }) => ({
        title,
        link,
        snippet,
      }));
      const summaryResult = await summarizeSearchResults({
        query,
        results: resultsForSummary,
      });
      summary = summaryResult.summary;
    } catch (error) {
      console.error('Failed to generate summary:', error);
      // Fail silently and don't show summary
      summary = '';
    }
  }

  return (
    <>
      {summary && (
        <Card className="mb-8 bg-muted/20">
          <CardHeader>
            <CardTitle className="text-xl">Resumo da IA</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm leading-relaxed">{summary}</p>
          </CardContent>
        </Card>
      )}
      {results.length > 0 && (
        <p className="mb-6 text-sm text-muted-foreground">
          Apresentando {results.length} resultados para{' '}
          <span className="font-semibold text-foreground">"{query}"</span>
        </p>
      )}
      {results.length > 0 ? (
        <div className="grid gap-6">
          {results.map(result => (
            <Card key={result.position}>
              <CardHeader>
                <CardTitle className="text-lg">
                  <a
                    href={result.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    {result.title}
                  </a>
                </CardTitle>
                <p className="text-sm text-green-700 dark:text-green-500">
                  {result.link}
                </p>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  {result.snippet}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex h-64 flex-col items-center justify-center rounded-lg border border-dashed">
          <h2 className="text-xl font-semibold">Nenhum resultado encontrado</h2>
          <p className="mt-2 text-muted-foreground">
            Tente uma pesquisa diferente.
          </p>
        </div>
      )}
    </>
  );
}

function ImageResultsSkeleton() {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
      {Array.from({ length: 10 }).map((_, i) => (
        <Card key={i} className="overflow-hidden">
          <Skeleton className="aspect-square w-full" />
          <div className="p-3">
            <Skeleton className="h-3 w-full" />
          </div>
        </Card>
      ))}
    </div>
  );
}

async function ImageResults({ query }: { query: string }) {
  if (!query) {
    return null;
  }

  const imageData = await searchImages({ query });
  const { results } = imageData;

  return (
    <>
      {results.length > 0 ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {results.map(result => (
            <a
              key={result.position}
              href={result.link}
              target="_blank"
              rel="noopener noreferrer"
              className="group"
            >
              <Card className="overflow-hidden">
                <div className="aspect-square relative">
                  <Image
                    src={result.imageUrl}
                    alt={result.title}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="p-3">
                  <p className="truncate text-xs text-muted-foreground">
                    {result.title}
                  </p>
                </div>
              </Card>
            </a>
          ))}
        </div>
      ) : (
        <div className="flex h-64 flex-col items-center justify-center rounded-lg border border-dashed">
          <h2 className="text-xl font-semibold">Nenhuma imagem encontrada</h2>
          <p className="mt-2 text-muted-foreground">
            Tente uma pesquisa diferente.
          </p>
        </div>
      )}
    </>
  );
}

function VideoResultsSkeleton() {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <Card key={i} className="overflow-hidden">
          <Skeleton className="aspect-video w-full" />
          <div className="p-4 space-y-2">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/4" />
            <Skeleton className="h-3 w-full" />
            <Skeleton className="h-3 w-full" />
          </div>
        </Card>
      ))}
    </div>
  );
}

async function VideoResults({ query }: { query: string }) {
  if (!query) {
    return null;
  }

  const videoData = await searchVideos({ query });
  const { results } = videoData;

  return (
    <>
      {results.length > 0 ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {results.map(result => (
            <a
              key={result.position}
              href={result.link}
              target="_blank"
              rel="noopener noreferrer"
              className="group"
            >
              <Card className="overflow-hidden">
                <div className="aspect-video relative">
                  <Image
                    src={result.imageUrl}
                    alt={result.title}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-sm group-hover:text-primary">
                    {result.title}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    {result.source} - {result.duration}
                  </p>
                  <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                    {result.snippet}
                  </p>
                </div>
              </Card>
            </a>
          ))}
        </div>
      ) : (
        <div className="flex h-64 flex-col items-center justify-center rounded-lg border border-dashed">
          <h2 className="text-xl font-semibold">Nenhum vídeo encontrado</h2>
          <p className="mt-2 text-muted-foreground">
            Tente uma pesquisa diferente.
          </p>
        </div>
      )}
    </>
  );
}

function NewsResultsSkeleton() {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <Card key={i} className="overflow-hidden">
          <Skeleton className="aspect-video w-full" />
          <div className="p-4 space-y-2">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/4" />
            <Skeleton className="h-3 w-full" />
            <Skeleton className="h-3 w-full" />
          </div>
        </Card>
      ))}
    </div>
  );
}

async function NewsResults({ query }: { query: string }) {
  if (!query) {
    return null;
  }

  const newsData = await searchNews({ query });
  const { results } = newsData;

  return (
    <>
      {results.length > 0 ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {results.map(result => (
            <a
              key={result.position}
              href={result.link}
              target="_blank"
              rel="noopener noreferrer"
              className="group"
            >
              <Card className="overflow-hidden">
                <div className="aspect-video relative bg-muted flex items-center justify-center">
                  {result.imageUrl ? (
                    <Image
                      src={result.imageUrl}
                      alt={result.title}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  ) : (
                    <Newspaper className="h-12 w-12 text-muted-foreground" />
                  )}
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-sm group-hover:text-primary">
                    {result.title}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    {result.source} - {new Date(result.date).toLocaleDateString()}
                  </p>
                  <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                    {result.snippet}
                  </p>
                </div>
              </Card>
            </a>
          ))}
        </div>
      ) : (
        <div className="flex h-64 flex-col items-center justify-center rounded-lg border border-dashed">
          <h2 className="text-xl font-semibold">Nenhuma notícia encontrada</h2>
          <p className="mt-2 text-muted-foreground">
            Tente uma pesquisa diferente.
          </p>
        </div>
      )}
    </>
  );
}


function SearchResults({ query, tab }: { query: string; tab: string }) {
  if (!query) {
    return null;
  }

  if (tab === 'images') {
    return (
      <Suspense fallback={<ImageResultsSkeleton />}>
        <ImageResults query={query} />
      </Suspense>
    );
  } else if (tab === 'videos') {
    return (
      <Suspense fallback={<VideoResultsSkeleton />}>
        <VideoResults query={query} />
      </Suspense>
    );
  } else if (tab === 'news') {
    return (
      <Suspense fallback={<NewsResultsSkeleton />}>
        <NewsResults query={query} />
      </Suspense>
    );
  }
  return (
    <Suspense fallback={<WebSearchResultsSkeleton />}>
      <WebSearchResults query={query} />
    </Suspense>
  );
}

export default function SearchPage({
  searchParams,
}: {
  searchParams?: { q?: string; t?: string };
}) {
  const query = searchParams?.q || '';
  const tab = searchParams?.t || 'web';

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur-sm">
        <div className="container mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
          <div className="hidden sm:block">
            <Logo />
          </div>
          <div className="flex-1">
            <Suspense>
              <SearchBar />
            </Suspense>
          </div>
        </div>
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Tabs value={tab} className="w-full">
            <TabsList>
              <TabsTrigger asChild value="web">
                <Link href={{ pathname: '/search', query: { q: query } }}>
                  Todos
                </Link>
              </TabsTrigger>
              <TabsTrigger asChild value="images">
                <Link
                  href={{
                    pathname: '/search',
                    query: { q: query, t: 'images' },
                  }}
                >
                  Imagens
                </Link>
              </TabsTrigger>
              <TabsTrigger asChild value="videos">
                <Link
                  href={{
                    pathname: '/search',
                    query: { q: query, t: 'videos' },
                  }}
                >
                  Vídeos
                </Link>
              </TabsTrigger>
              <TabsTrigger asChild value="news">
                <Link
                  href={{
                    pathname: '/search',
                    query: { q: query, t: 'news' },
                  }}
                >
                  Notícias
                </Link>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </header>
      <main className="flex-1">
        <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <SearchResults query={query} tab={tab} />
        </div>
      </main>
    </div>
  );
}
