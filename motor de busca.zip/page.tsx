import { Suspense } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import SearchBar from '@/components/search-bar';
import { Logo } from '@/components/logo';
import { searchNews } from '@/ai/flows/search-news';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Newspaper } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export const revalidate = 3600; // Revalida a cada hora (3600 segundos)

async function LatestNews() {
  const newsData = await searchNews({ query: 'Últimas Notícias' });
  const results = newsData.results.slice(0, 8); // Pega as 8 primeiras notícias

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {results.map(result => (
        <a
          key={result.position}
          href={result.link}
          target="_blank"
          rel="noopener noreferrer"
          className="group"
        >
          <Card className="flex h-full flex-col overflow-hidden">
            <div className="aspect-video relative bg-muted flex items-center justify-center">
              {result.imageUrl ? (
                <Image
                  src={result.imageUrl}
                  alt={result.title}
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
              ) : (
                <Newspaper className="h-12 w-12 text-muted-foreground" />
              )}
            </div>
            <CardHeader className="flex-grow">
              <CardTitle className="text-base font-semibold group-hover:text-primary">
                {result.title}
              </CardTitle>
            </CardHeader>
            <CardFooter>
              <p className="text-xs text-muted-foreground">
                {result.source} - {new Date(result.date).toLocaleDateString()}
              </p>
            </CardFooter>
          </Card>
        </a>
      ))}
    </div>
  );
}

function LatestNewsSkeleton() {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <Card key={i} className="flex h-full flex-col overflow-hidden">
          <Skeleton className="aspect-video w-full" />
          <CardHeader className="flex-grow">
            <Skeleton className="h-4 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2" />
          </CardHeader>
          <CardFooter>
            <Skeleton className="h-3 w-1/3" />
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}

async function FootballNews() {
  const newsData = await searchNews({ query: 'Futebol' });
  const results = newsData.results.slice(0, 4); // Pega as 4 primeiras notícias

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {results.map(result => (
        <a
          key={result.position}
          href={result.link}
          target="_blank"
          rel="noopener noreferrer"
          className="group"
        >
          <Card className="flex h-full flex-col overflow-hidden">
            <div className="aspect-video relative bg-muted flex items-center justify-center">
              {result.imageUrl ? (
                <Image
                  src={result.imageUrl}
                  alt={result.title}
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
              ) : (
                <Newspaper className="h-12 w-12 text-muted-foreground" />
              )}
            </div>
            <CardHeader className="flex-grow">
              <CardTitle className="text-base font-semibold group-hover:text-primary">
                {result.title}
              </CardTitle>
            </CardHeader>
            <CardFooter>
              <p className="text-xs text-muted-foreground">
                {result.source} - {new Date(result.date).toLocaleDateString()}
              </p>
            </CardFooter>
          </Card>
        </a>
      ))}
    </div>
  );
}

function FootballNewsSkeleton() {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i} className="flex h-full flex-col overflow-hidden">
          <Skeleton className="aspect-video w-full" />
          <CardHeader className="flex-grow">
            <Skeleton className="h-4 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2" />
          </CardHeader>
          <CardFooter>
            <Skeleton className="h-3 w-1/3" />
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}

export default function Home() {
  return (
    <main className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto flex w-full max-w-2xl flex-col items-center gap-8 mb-12">
        <Logo />
        <Suspense>
          <SearchBar />
        </Suspense>
      </div>

      <h2 className="text-2xl font-bold tracking-tight mb-6">
        Novidades
      </h2>
      <Suspense fallback={<LatestNewsSkeleton />}>
        <LatestNews />
      </Suspense>

      <h2 className="text-2xl font-bold tracking-tight mb-6 mt-12">
        Futebol
      </h2>
      <Suspense fallback={<FootballNewsSkeleton />}>
        <FootballNews />
      </Suspense>
    </main>
  );
}
